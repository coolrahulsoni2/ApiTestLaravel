<?php 
$server="localhost";
$user="KNR";
$pass="connect10";
$db="FNM1";
$con=mysqli_connect($server,$user,$pass,$db) or die("Could not connect database");
?>

